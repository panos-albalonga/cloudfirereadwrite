package com.albalonga.cloudfirereadwrite;

public enum Suit {
    S,      // Spades
    C,      // Clubs
    D,      // Diamonds
    H       // Hearts
}
